import numpy as np
from question_tuple import QUESTION_TUPLE

SUB_QUEST = 18
N_SUBSURVEYS = 14
PERSONAL_DATA_SURVEY_POS = "scritte_survey\\dati_personali_survey.txt"
INTRO_SUB_POS = "scritte_survey\\intro_sub_survey.txt"
survey_path = "outputs\\survey.txt"

EXP_PARTICIPANTS = 100
N_ANS = 7
DONE_SUBS = 0
SAFE_RATIO = 0.9

# Scala gender
GENDER_SCALE = """scale: gender
item: <i></i>
- {score=-2} Completamente femminile
- {score=-1} Più femminile che maschile
- {score=0} Neutro
- {score=1} Più maschile che femminile
- {score=2} Completamente maschile

"""

# Funzione per generare una domanda normale
def make_ptk_question(q_id: str, text: str, suffix: str) -> str:
    return f"""page: begin

l: {q_id}_{suffix}
t: scale gender
o: free
q: {text}
-

l: no_{q_id}_{suffix}
t: radio
o: free
q: <i></i>
- <i> Non so / Preferisco non rispondere </i>

page: end


"""

# ------------------------------
# ⭐ DOMANDE DI TEST (STRUTTURE ORIGINALI)
# ------------------------------

def test_quest1(suffix: str) -> str:
    return f"""
page: begin

l: test1_{suffix}
t: scale gender
o: free
q: Un altro aspetto da considerare, come si è detto, è la determinazione dell’efficacia e della sicurezza del farmaco nelle donne che sono le più esposte alla demenza di Alzheimer per svariate ragioni. Questa è una domanda di prova, risponda: Completamente Maschile
-

l: no_test1_{suffix}
t: radio
o: free
q: <i></i>
- <i> Non so / Preferisco non rispondere </i>

page: end


"""

def test_quest2(suffix: str) -> str:
    return f"""
page: begin

l: test2_{suffix}
t: scale gender
o: free
q: L'effetto dell'instabilità strutturale permanente, della fine della visione «di lungo corso», non può che essere stagnazione e conservazione, altro che innovazione. Questa è una domanda di prova, risponda: Più femminile che maschile
-

l: no_test2_{suffix}
t: radio
o: free
q: <i></i>
- <i> Non so / Preferisco non rispondere </i>

page: end


"""

# ------------------------------

# Carico intro e dati personali
with open(INTRO_SUB_POS, 'r', encoding='utf-8') as s_intro_file:
    sub_intro = s_intro_file.read()

with open(PERSONAL_DATA_SURVEY_POS, 'r', encoding='utf-8') as dp:
    personal_questions = dp.read()

# Metto domande in lista (solo id e testo)
all_questions = [(q_id, text) for (q_id, text, cat) in QUESTION_TUPLE]

# Scrivo scala gender all'inizio
with open(survey_path, "w", encoding="utf-8") as s:
    s.write(GENDER_SCALE)

# Aggiungo survey
with open(survey_path, "a", encoding="utf-8") as survey:

    choosable = int((EXP_PARTICIPANTS / N_ANS) * SAFE_RATIO + 0.5)
    end = DONE_SUBS + choosable

    survey.write(f"l: choose_sub \nt: set \n- random {DONE_SUBS} {end}\n\n")
    survey.write("l:\nt: jump\n")
    for i in range(N_SUBSURVEYS):
        survey.write(f"- if $choose_sub == {i} then goto sub_intro_{i}\n")
    survey.write("\n")

    # Genero i sub-surveys
    for i in range(N_SUBSURVEYS):

        suffix = f"s{i}"  # suffisso per label uniche

        survey.write(f"\n\n## Sub-survey {i} ##################\n\n")
        survey.write(f"l: sub_intro_{i}\nt: info \nq: <i>[sub-codice: {i}]</i>{sub_intro}\n\n")

        # Domande random senza duplicati
        indices = np.random.choice(len(all_questions), size=SUB_QUEST, replace=False)

        # Creo domande normali
        sub_questions = [make_ptk_question(*all_questions[idx], suffix) for idx in indices]

        # Aggiungo domande test ORIGINALI
        sub_questions.append(test_quest1(suffix))
        sub_questions.append(test_quest2(suffix))

        # Mischio tutte le domande (test incluse)
        np.random.shuffle(sub_questions)

        # Scrivo le domande
        for q in sub_questions:
            survey.write(q)

        survey.write(f"\n\nl: sub_end_{i}\nt: jump \n- goto language\n\n")

    # Scrivo le domande personali
    survey.write(personal_questions)

print(f"Output survey in {survey_path}")
