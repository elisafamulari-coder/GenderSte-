import os
import unicodedata

def question_tuple(path="dataset2_Survey.txt"):
    """
    Legge il dataset e converte ogni riga in una tupla:
        (id, testo, categoria)
    categoria = N / F / M
    """
    tuples = []

    if not os.path.exists(path):
        raise FileNotFoundError(f"Dataset file not found: {path}")

    with open(path, "r", encoding="utf-8") as f:   # <- UTF-8 per leggere correttamente i caratteri speciali
        for line_num, line in enumerate(f, start=1):
            line = line.strip()
            if not line:
                continue

            fields = line.split('\t')
            if len(fields) < 3:
                print(f"[WARN] Riga {line_num} ignorata: meno di 3 colonne")
                continue

            q_id = fields[0].strip()
            text_raw = fields[2].strip()   # TERZA COLONNA = testo reale
            text = unicodedata.normalize('NFC', text_raw)

            # Categoria basata sulla prima lettera dell'ID
            categoria = q_id[0].upper() if q_id[0].upper() in {"N", "F", "M"} else "N"

            tuples.append((q_id, text, categoria))

    print(f"[INFO] Domande caricate: {len(tuples)}")
    return tuples

# Caricamento automatico
QUESTION_TUPLE = question_tuple()



