import re

input_path = "dataset2_Survey.txt"   # il file originale
output_path = "dataset2clean.txt"  # il file ripulito

with open(input_path, "r", encoding="latin-1") as f_in, open(output_path, "w", encoding="latin-1") as f_out:
    for line in f_in:
        line = line.strip()
        if not line:
            continue
        # Rimuove tab/space prima e dopo quadruple virgolette
        line = re.sub(r'\t*""""\t*', '""""', line)
        # Rimuove tab/space multipli finali
        line = line.rstrip()
        f_out.write(line + "\n")

print(f"File ripulito salvato in: {output_path}")
